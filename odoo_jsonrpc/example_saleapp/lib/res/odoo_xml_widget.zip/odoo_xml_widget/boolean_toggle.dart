import 'package:flutter/material.dart';

class BooleanToggleFieldWidget extends StatefulWidget {
  final String name; // Field name
  final bool value; // Current value (boolean)
  final ValueChanged<bool>? onChanged; // Callback for value change

  const BooleanToggleFieldWidget({
    required this.name,
    required this.value,
    this.onChanged,
  });

  @override
  _BooleanToggleFieldWidgetState createState() => _BooleanToggleFieldWidgetState();
}

class _BooleanToggleFieldWidgetState extends State<BooleanToggleFieldWidget> {
  late bool _currentValue;

  @override
  void initState() {
    super.initState();
    _currentValue = widget.value; // Initialize with the current value
  }

  // Handle value change
  void _onChanged(bool newValue) {
    setState(() {
      _currentValue = newValue;
    });
    if (widget.onChanged != null) {
      widget.onChanged!(newValue);
    }
    print('New value for ${widget.name}: $newValue');
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.name,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            value: _currentValue,
            onChanged: _onChanged,
            title: Text('Toggle ${widget.name}'),
            activeColor: Colors.green, // Customize the toggle color if needed
          ),
        ],
      ),
    );
  }
}
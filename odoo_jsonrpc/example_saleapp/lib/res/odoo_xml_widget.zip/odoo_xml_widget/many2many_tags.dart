import 'package:flutter/material.dart';

class Many2ManyTagsWidget extends StatefulWidget {
  final String name;
  final List<dynamic> values;
  final List<Map<String, dynamic>> options;
  final Function(List<dynamic>) onValuesChanged;

  const Many2ManyTagsWidget({
    Key? key,
    required this.name,
    required this.values,
    required this.options,
    required this.onValuesChanged,
  }) : super(key: key);

  @override
  _Many2ManyTagsWidgetState createState() => _Many2ManyTagsWidgetState();
}

class _Many2ManyTagsWidgetState extends State<Many2ManyTagsWidget> {
  late List<dynamic> selectedValues;

  @override
  void initState() {
    super.initState();
    selectedValues = List.from(widget.values);
  }

  String _getDisplayName(dynamic id) {
    final option = widget.options.firstWhere(
          (opt) => opt['id'] == id,
      orElse: () => {'name': 'Unknown'},
    );
    return option['name'] as String;
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.name,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8.0,
            children: selectedValues.map((value) {
              return Chip(
                label: Text(_getDisplayName(value)),
                onDeleted: () {
                  setState(() {
                    selectedValues.remove(value);
                  });
                  widget.onValuesChanged(selectedValues);
                },
                backgroundColor: Colors.blueGrey.withOpacity(0.1),
                labelStyle: const TextStyle(color: Colors.black),
              );
            }).toList(),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<int>(
            isExpanded: true,
            hint: Text('Select ${widget.name}'),
            items: widget.options.map((option) {
              return DropdownMenuItem<int>(
                value: option['id'],
                child: StatefulBuilder(
                  builder: (context, setState) {
                    return CheckboxListTile(
                      title: Text(option['name'] ?? 'Unnamed Option'),
                      value: selectedValues.contains(option['id']),
                      onChanged: (isChecked) {
                        setState(() {
                          if (isChecked == true) {
                            selectedValues.add(option['id']);
                          } else {
                            selectedValues.remove(option['id']);
                          }
                          widget.onValuesChanged(selectedValues);
                        });
                        // Trigger rebuild of the parent widget
                        this.setState(() {});
                      },
                      controlAffinity: ListTileControlAffinity.leading,
                    );
                  },
                ),
              );
            }).toList(),
            onChanged: (value) {}, // Empty onChanged as we handle it in CheckboxListTile
            decoration: const InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
    );
  }
}
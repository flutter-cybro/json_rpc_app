import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart'; // For icons

class ImageFieldWidget extends StatefulWidget {
  final String name; // Field name
  final dynamic value; // Current value (base64 string or null)
  final Function(String) onChanged; // Callback for value change

  const ImageFieldWidget({
    Key? key,
    required this.name,
    required this.value,
    required this.onChanged,
  }) : super(key: key);

  @override
  _ImageFieldWidgetState createState() => _ImageFieldWidgetState();
}

class _ImageFieldWidgetState extends State<ImageFieldWidget> {
  final ImagePicker _picker = ImagePicker();
  String? _base64Image;

  @override
  void initState() {
    super.initState();
    if (widget.value != null && widget.value is String) {
      _base64Image = widget.value; // Load existing base64 image
    }
  }

  Future<void> _pickImage() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final bytes = await pickedFile.readAsBytes();
      final base64String = base64Encode(bytes);

      setState(() {
        _base64Image = base64String;
      });

      widget.onChanged(base64String); // Notify parent widget
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        _base64Image != null
            ? Stack(
          alignment: Alignment.topRight,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.memory(
                base64Decode(_base64Image!),
                width: 150,
                height: 150,
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: Icon(
                FontAwesomeIcons.image, // Image icon instead of phone
                size: 16, // Small icon
                color: Colors.grey.withOpacity(0.5), // Faded color
              ),
            ),
          ],
        )
            : _buildImagePlaceholder(),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: _pickImage,
          icon: const Icon(Icons.upload),
          label: const Text("Upload Image"),
        ),
      ],
    );
  }

  Widget _buildImagePlaceholder() {
    return Container(
      width: 150,
      height: 150,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          const Icon(Icons.image_not_supported, size: 50, color: Colors.grey),
          Positioned(
            top: 4,
            right: 4,
            child: Icon(
              FontAwesomeIcons.image, // Small image icon
              size: 16, // Small size
              color: Colors.grey.withOpacity(0.5), // Faded color
            ),
          ),
        ],
      ),
    );
  }
}
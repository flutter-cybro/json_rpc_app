import 'package:flutter/material.dart';

class HrHomeworkingRadioImageWidget extends StatefulWidget {
  final String name; // Field name
  final dynamic value; // Current value (e.g., 'office')
  final List<Map<String, dynamic>> options; // Options from parent or pythonAttributes
  final ValueChanged<dynamic> onChanged; // Callback for value change
  final Map<String, dynamic>? pythonAttributes; // Python attributes for dynamic selection

  const HrHomeworkingRadioImageWidget({
    Key? key,
    required this.name,
    required this.value,
    required this.options,
    required this.onChanged,
    this.pythonAttributes,
  }) : super(key: key);

  @override
  _HrHomeworkingRadioImageWidgetState createState() => _HrHomeworkingRadioImageWidgetState();
}

class _HrHomeworkingRadioImageWidgetState extends State<HrHomeworkingRadioImageWidget> {
  late dynamic _selectedValue;

  @override
  void initState() {
    super.initState();
    _selectedValue = widget.value; // Initialize with current value
  }

  // Helper method to extract selection options from pythonAttributes or fallback to options
  List<Map<String, dynamic>> _getSelectionOptions() {
    if (widget.pythonAttributes != null && widget.pythonAttributes!['type'] == 'selection') {
      final selection = widget.pythonAttributes!['selection'] as List<dynamic>?;
      if (selection != null && selection.isNotEmpty) {
        return selection.map((item) {
          final key = item[0] as String;
          final val = item[1] as String;
          return {'id': key, 'name': val};
        }).toList();
      }
    }
    return widget.options;
  }

  // Map selection keys to image assets (customize as needed)
  String _getImageForOption(String id) {
    switch (id) {
      case 'office':
        return 'assets/images/office.png'; // Replace with your asset path
      case 'home':
        return 'assets/images/home.png';
      default:
        return 'assets/images/default.png'; // Fallback image
    }
  }

  @override
  Widget build(BuildContext context) {
    final selectionOptions = _getSelectionOptions();

    // Debugging output
    print('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>');
    print('Field Name: ${widget.name}');
    print('Current Value: $_selectedValue');
    print('Selection Options: $selectionOptions');

    // Validate the value
    if (!selectionOptions.any((opt) => opt['id'] == _selectedValue)) {
      _selectedValue = null; // Reset if invalid
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            widget.name,
            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          Column(
            children: selectionOptions.map((option) {
              final id = option['id'] as String;
              final name = option['name'] as String;
              return RadioListTile<dynamic>(
                value: id,
                groupValue: _selectedValue,
                onChanged: (newValue) {
                  setState(() {
                    _selectedValue = newValue;
                  });
                  widget.onChanged(newValue);
                },
                title: Row(
                  children: [
                    // Image.asset(
                    //   _getImageForOption(id),
                    //   width: 24, // Small image size
                    //   height: 24,
                    //   color: Colors.grey.withOpacity(0.5), // Faded effect
                    //   errorBuilder: (context, error, stackTrace) => const Icon(
                    //     Icons.image_not_supported,
                    //     size: 24,
                    //     color: Colors.grey,
                    //   ),
                    // ),
                    // const SizedBox(width: 10),
                    Text(name),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
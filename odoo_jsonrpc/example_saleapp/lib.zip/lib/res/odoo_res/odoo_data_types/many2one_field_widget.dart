import 'package:flutter/material.dart';
import 'dart:developer';

class Many2OneFieldWidget extends StatefulWidget {
  final String name;
  final dynamic value;
  final List<Map<String, dynamic>> options;
  final Function(dynamic) onValueChanged;
  final String viewType;

  const Many2OneFieldWidget({
    required this.name,
    required this.value,
    required this.options,
    required this.onValueChanged,
    super.key,
    this.viewType = 'form',
  });

  @override
  _Many2OneFieldWidgetState createState() => _Many2OneFieldWidgetState();
}

class _Many2OneFieldWidgetState extends State<Many2OneFieldWidget> {
  dynamic selectedValue;

  @override
  void initState() {
    super.initState();
    _updateSelectedValue(widget.value);
  }

  @override
  void didUpdateWidget(Many2OneFieldWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value || oldWidget.options != widget.options) {
      _updateSelectedValue(widget.value);
    }
  }

  void _updateSelectedValue(dynamic value) {
    final valueId = (value is List && value.isNotEmpty) ? value[0] : value;
    final existsInOptions = widget.options.any((option) => option['id'] == valueId);
    setState(() {
      selectedValue = existsInOptions ? valueId : null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final uniqueOptions = _removeDuplicateOptions(widget.options);

    if (widget.viewType == 'tree') {
      return DropdownButtonFormField<dynamic>(
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8.0),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
        ),
        value: selectedValue,
        items: uniqueOptions
            .map((option) => DropdownMenuItem<dynamic>(
          value: option['id'],
          child: Text(option['name']?.toString() ?? 'Unnamed'),
        ))
            .toList(),
        onChanged: (newValue) {
          setState(() {
            selectedValue = newValue;
          });
          widget.onValueChanged(newValue);
        },
        isExpanded: true,
        hint: const Text('Select an option'),
      );
    } else {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 150,
              child: Padding(
                padding: const EdgeInsets.only(top: 8.0, right: 8.0),
                child: Text(
                  '${widget.name}:',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14.0),
                ),
              ),
            ),
            Expanded(
              child: DropdownButtonFormField<dynamic>(
                decoration: InputDecoration(
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
                ),
                value: selectedValue,
                items: uniqueOptions
                    .map((option) => DropdownMenuItem<dynamic>(
                  value: option['id'],
                  child: Text(option['name']?.toString() ?? 'Unnamed'),
                ))
                    .toList(),
                onChanged: (newValue) {
                  setState(() {
                    selectedValue = newValue;
                  });
                  widget.onValueChanged(newValue);
                },
                isExpanded: true,
                hint: const Text('Select an option'),
              ),
            ),
          ],
        ),
      );
    }
  }

  List<Map<String, dynamic>> _removeDuplicateOptions(List<Map<String, dynamic>> options) {
    final seenIds = <dynamic>{};
    final uniqueOptions = <Map<String, dynamic>>[];

    for (var option in options) {
      final id = option['id'];
      if (id != null && !seenIds.contains(id)) {
        seenIds.add(id);
        uniqueOptions.add(option);
      } else if (id != null) {
      }
    }

    return uniqueOptions;
  }
}
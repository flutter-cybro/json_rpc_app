
import 'package:flutter/material.dart';

class CharFieldWidget extends StatelessWidget {
  final String name;
  final String value;
  final Function(String)? onChanged;

  const CharFieldWidget({
    required this.name,
    required this.value,
    this.onChanged,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              '$name:',
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14.0),
            ),
          ),
          Expanded(
            child: TextField(
              controller: TextEditingController(text: value),
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
                contentPadding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 8.0),
              ),
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}
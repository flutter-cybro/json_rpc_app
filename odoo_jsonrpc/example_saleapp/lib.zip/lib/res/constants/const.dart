enum AuthenticationResult {
  success,
  failure,
  error,
  unavailable,
}

const String DEFAULT_SERVER_ADDRESS = 'http://10.0.20.129:8018/';
const String DEFAULT_PASSWORD = '1';
const String DEFAULT_USERNAME = '1';
import 'dart:ui';

import 'package:flutter/material.dart';

Color ODOO_COLOR = Color(0xFF7D3C98);

Color WHITE_COLOR = Colors.white;

Color GREEN_COLOR = Colors.green;

Color BLACK_COLOR = Colors.black;

Color BLACK87 = Colors.black87;

